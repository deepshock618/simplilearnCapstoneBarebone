package com.tele.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tele.dao.IssueRepository;
import com.tele.entities.Issue;

@Service
public class IssueService {

	@Autowired
	IssueRepository issueRepo;
	
	public void saveIssue(Issue issue)
	{
		issueRepo.save(issue);
	}
	
	
	public void updateIssue(Issue issue) {
		issueRepo.save(issue);
	}
	
	
	public List<Issue> getAllIssues()
	{	
		Iterable<Issue> iterable=issueRepo.findAll();
		List<Issue> issues=new ArrayList<>();
		iterable.forEach(iter->issues.add(iter));
		return issues;
	}
	
	
	public Issue getIssueById(int id)
	{
		Optional<Issue>optional=issueRepo.findById(id);
		Issue issue=optional.get();
		return issue;
	}
	
	public List<Issue> getIssueByCustomerId(int customerId)
	{
		List<Issue> issues=issueRepo.findByCustomerId(customerId);
		return issues;
	}
	
	public List<Issue> getIssueByEngineerId(int engineerId)
	{
		List<Issue> issues=issueRepo.findByEngineerId(engineerId);
		return issues;
	}
		
	public void updateIssueEngineerId(int engineerId, int id) {
		Issue issue=getIssueById(id);
		issue.setEngineerId(engineerId);
		issueRepo.save(issue);
		
	}
	
	public void updateStatus(String status, int id) {
		Issue issue=getIssueById(id);
		issue.setStatus(status);
		issueRepo.save(issue);
		
	}
	
	public void updateRemarks(String remarks, int id) {
		Issue issue=getIssueById(id);
		issue.setRemarks(remarks);
		issueRepo.save(issue);
		
	}
	
	public void deleteIssue(int id)
	{
		Issue issue=getIssueById(id);
		issueRepo.delete(issue);
	}
	
}
