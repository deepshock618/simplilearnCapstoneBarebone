package com.tele.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Engineer {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private String pin;
	private String password;
	
	
	public Engineer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Engineer(int id, String name, String pin, String password) {
		super();
		this.id = id;
		this.name = name;
		this.pin = pin;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Engineer [id=" + id + ", name=" + name + ", pin=" + pin + ", password=" + password + "]";
	}
	
}
