package com.tele.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Issue;

public interface IssueRepository extends CrudRepository<Issue, Integer>{

	public List<Issue> findByCustomerId(int customerId);
	public List<Issue> findByEngineerId(int engineerId);
}
