package com.tele.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tele.entities.Feedback;
import com.tele.entities.Issue;
import com.tele.services.CustomerService;
import com.tele.services.FeedbackService;
import com.tele.services.IssueService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	IssueService issueServ;
	
	@Autowired
	FeedbackService feedbackServ;
	
	@Autowired
	CustomerService customerServ;
	
	
	@PostMapping("/issue")
	public void raiseIssue(@RequestBody Issue issue)
	{
		issueServ.saveIssue(issue);
	}
	
	@PostMapping("/feedback")
	public void addFeedback(@RequestBody Feedback feedback)
	{
		feedbackServ.saveFeedback(feedback);
	}
	
	@GetMapping("/issues/{cId}")
	public List<Issue> getCustomerIssues(@PathVariable("cId") int cId)
	{
		return issueServ.getIssueByCustomerId(cId);
	}
	
	@PutMapping("/customerPassword/{cId}")
	public void changePassword(@PathVariable("cId") int cId,@RequestBody String password)
	{
		customerServ.updateCustomerPassword(cId,password);
	}
}
