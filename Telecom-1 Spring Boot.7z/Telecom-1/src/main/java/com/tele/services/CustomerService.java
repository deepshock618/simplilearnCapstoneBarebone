package com.tele.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tele.dao.CustomerRepository;
import com.tele.entities.Customer;


@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepo;
	
	public void saveCustomer(Customer customer)
	{
		customerRepo.save(customer);
	}
	
	public List<Customer> getAllCustomers()
	{	
		Iterable<Customer> iterable=customerRepo.findAll();
		List<Customer> customers=new ArrayList<>();
		iterable.forEach(iter->customers.add(iter));
		return customers;
	}
	
	public Customer getCustomerById(int id)
	{
		Optional<Customer>optional=customerRepo.findById(id);
		Customer customer=optional.get();
		return customer;
	}
	
	public void updateCustomer(Customer customer) {
		customerRepo.save(customer);
		
	}
	
	public void updateCustomerPassword(int id, String password) {
		Customer customer=getCustomerById(id);
		customer.setPassword(password);
		customerRepo.save(customer);
		
	}
	
	public void deleteCustomer(int id)
	{
		Customer customer=getCustomerById(id);
		customerRepo.delete(customer);
	}
}
