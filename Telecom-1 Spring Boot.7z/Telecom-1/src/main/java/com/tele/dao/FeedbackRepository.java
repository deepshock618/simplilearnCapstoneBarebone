package com.tele.dao;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Feedback;

public interface FeedbackRepository extends CrudRepository<Feedback,Integer>{

}
