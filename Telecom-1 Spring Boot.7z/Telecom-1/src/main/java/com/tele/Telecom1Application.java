package com.tele;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Telecom1Application {

	public static void main(String[] args) {
		SpringApplication.run(Telecom1Application.class, args);
	}

}
