package com.tele.dao;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Admin;

public interface AdminRepository extends CrudRepository<Admin,Integer> {

}
