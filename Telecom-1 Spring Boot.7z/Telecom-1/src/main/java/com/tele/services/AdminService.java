package com.tele.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tele.dao.AdminRepository;
import com.tele.entities.Admin;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepo;
	
	public void saveAdmin(Admin admin)
	{
		admin.setId(1);
		adminRepo.save(admin);
	}
	public Admin getById(int id)
	{
		Optional<Admin>optional=adminRepo.findById(id);
		Admin admin=optional.get();
		return admin;
	}
	public void updateAdminPassword(String password) {
		Admin admin=getById(1);
		admin.setPassword(password);
		adminRepo.save(admin);
		
	}
}
