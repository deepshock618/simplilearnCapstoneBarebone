package com.tele.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tele.entities.Customer;
import com.tele.entities.Engineer;
import com.tele.entities.Feedback;
import com.tele.entities.Issue;
import com.tele.entities.Manager;
import com.tele.services.CustomerService;
import com.tele.services.EngineerService;
import com.tele.services.FeedbackService;
import com.tele.services.IssueService;
import com.tele.services.ManagerService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	IssueService issueServ;
	
	@Autowired
	FeedbackService feedbackServ;
	
	@Autowired
	CustomerService customerServ;
	
	@Autowired
	EngineerService engineerServ;
	
	@Autowired
	ManagerService managerServ;
	
	
	@PostMapping("/issue")
	public void raiseIssue(@RequestBody Issue issue)
	{
		issueServ.saveIssue(issue);
	}
	
	@GetMapping("/issues")
	public List<Issue> getIssues()
	{
		return issueServ.getAllIssues();
	}
	
	@GetMapping("/issue/{iId}")
	public Issue getIssue(@PathVariable("iId") int iId)
	{
		return issueServ.getIssueById(iId);
	}
	
	@PutMapping("/issue")
	public void updateIssue(@RequestBody Issue issue)
	{
		issueServ.updateIssue(issue);
	}
	
	@DeleteMapping("/issue/{iId}")
	public void deleteIssue(@PathVariable("iId") int iId)
	{
		issueServ.deleteIssue(iId);
	}
	
	@PostMapping("/manager")
	public void saveManager(@RequestBody Manager manager)
	{
		managerServ.saveManager(manager);
	}
	
	@GetMapping("/managers")
	public List<Manager> getManagers()
	{
		return managerServ.getAllManagers();
	}
	
	@GetMapping("/manager/{mId}")
	public Manager getManager(@PathVariable("mId") int mId)
	{
		return managerServ.getManagerById(mId);
	}
	
	@PutMapping("/manager")
	public void updateManager(@RequestBody Manager manager)
	{
		managerServ.updateManager(manager);
	}
	
	@DeleteMapping("/manager/{mId}")
	public void deleteManager(@PathVariable("mId") int mId)
	{
		managerServ.deleteManager(mId);
	}
	
	@PostMapping("/engineer")
	public void saveEngineer(@RequestBody Engineer engineer)
	{
		engineerServ.saveEngineer(engineer);
	}
	
	@GetMapping("/engineers")
	public List<Engineer> getEngineers()
	{
		return engineerServ.getAllEngineers();
	}
	
	@GetMapping("/engineer/{eId}")
	public Engineer getEngineer(@PathVariable("eId") int eId)
	{
		return engineerServ.getEngineerById(eId);
	}
	
	@PutMapping("/engineer")
	public void updateEngineer(@RequestBody Engineer engineer)
	{
		engineerServ.updateEngineer(engineer);
	}
	
	@DeleteMapping("/engineer/{eId}")
	public void deleteEngineer(@PathVariable("eId") int eId)
	{
		engineerServ.deleteEngineer(eId);
	}
	
	@PostMapping("/feedback")
	public void addFeedback(@RequestBody Feedback feedback)
	{
		feedbackServ.saveFeedback(feedback);
	}
	
	@GetMapping("/feedbacks")
	public List<Feedback> getFeedbacks()
	{
		return feedbackServ.getAllFeedbacks();
	}
	
	@GetMapping("/feedback/{fId}")
	public Feedback getFeedback(@PathVariable("fId") int fId)
	{
		return feedbackServ.getFeedbackById(fId);
	}
	
	@PutMapping("/feedback")
	public void updateFeedback(@RequestBody Feedback feedback)
	{
		feedbackServ.updateFeedback(feedback);
	}
	
	@DeleteMapping("/feedback/{fId}")
	public void deleteFeedback(@PathVariable("fId") int fId)
	{
		feedbackServ.deleteFeedback(fId);
	}
	
	@PostMapping("/customer")
	public void saveCustomer(@RequestBody Customer customer)
	{
		customerServ.saveCustomer(customer);
	}
	
	@GetMapping("/customers")
	public List<Customer> getCustomers()
	{
		return customerServ.getAllCustomers();
	}
	
	@GetMapping("/customer/{cId}")
	public Customer getCustomer(@PathVariable("cId") int cId)
	{
		return customerServ.getCustomerById(cId);
	}
	
	@PutMapping("/customer")
	public void updateCustomer(@RequestBody Customer customer)
	{
		customerServ.updateCustomer(customer);
	}
	
	@DeleteMapping("/customer/{cId}")
	public void deleteCustomer(@PathVariable("cId") int cId)
	{
		customerServ.deleteCustomer(cId);
	}
}
