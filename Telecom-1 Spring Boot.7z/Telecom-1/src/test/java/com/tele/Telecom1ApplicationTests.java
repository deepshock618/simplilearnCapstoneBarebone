package com.tele;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Telecom1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
