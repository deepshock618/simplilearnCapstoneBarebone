package com.tele.dao;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Manager;

public interface ManagerRepository extends CrudRepository<Manager,Integer> {

}
