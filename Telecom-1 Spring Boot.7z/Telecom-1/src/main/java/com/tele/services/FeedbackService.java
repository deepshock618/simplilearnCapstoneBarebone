package com.tele.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tele.dao.FeedbackRepository;
import com.tele.entities.Feedback;

@Service
public class FeedbackService {

	@Autowired
	FeedbackRepository feedbackRepo;
	
	public void saveFeedback(Feedback feedback)
	{
		feedbackRepo.save(feedback);
	}
	
	public List<Feedback> getAllFeedbacks()
	{	
		Iterable<Feedback> iterable=feedbackRepo.findAll();
		List<Feedback> feedbacks=new ArrayList<>();
		iterable.forEach(iter->feedbacks.add(iter));
		return feedbacks;
	}
	
	
	public Feedback getFeedbackById(int id)
	{
		Optional<Feedback>optional=feedbackRepo.findById(id);
		Feedback feedback=optional.get();
		return feedback;
	}
	
	public void updateFeedback(Feedback feedback)
	{
		feedbackRepo.save(feedback);
	}
	
	
	public void deleteFeedback(int id)
	{
		Feedback feedback=getFeedbackById(id);
		feedbackRepo.delete(feedback);
	}
}
