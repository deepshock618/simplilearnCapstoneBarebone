package com.tele.dao;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Engineer;

public interface EngineerRepository extends CrudRepository<Engineer,Integer>{

}
