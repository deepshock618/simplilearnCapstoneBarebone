package com.tele.dao;

import org.springframework.data.repository.CrudRepository;

import com.tele.entities.Customer;

public interface CustomerRepository extends CrudRepository<Customer,Integer> {

}
