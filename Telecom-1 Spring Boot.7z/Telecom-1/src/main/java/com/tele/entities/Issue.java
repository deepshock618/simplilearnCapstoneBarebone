package com.tele.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Value;

@Entity
public class Issue {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String title;
	private int customerId;
	private String writeup;
	private String pin;
	@Value("WIP")
	private String status;
	@Value("${0}")
	private int engineerId;
	@Value(" ")
	private String remarks;
	
	
	
	
	public Issue() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Issue(int id, String title, int customerId, String writeup, String pin, String status, int engineerId,
			String remarks) {
		super();
		this.id = id;
		this.title = title;
		this.customerId = customerId;
		this.writeup = writeup;
		this.pin = pin;
		this.status = status;
		this.engineerId = engineerId;
		this.remarks = remarks;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getWriteup() {
		return writeup;
	}
	public void setWriteup(String writeup) {
		this.writeup = writeup;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getEngineerId() {
		return engineerId;
	}
	public void setEngineerId(int engineerId) {
		this.engineerId = engineerId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Issue [id=" + id + ", title=" + title + ", customerId=" + customerId + ", writeup=" + writeup + ", pin="
				+ pin + ", status=" + status + ", engineerId=" + engineerId + ", remarks=" + remarks + "]";
	}
}
