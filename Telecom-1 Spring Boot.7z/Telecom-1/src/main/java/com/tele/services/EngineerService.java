package com.tele.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tele.dao.EngineerRepository;
import com.tele.entities.Engineer;

@Service
public class EngineerService {

	@Autowired
	EngineerRepository engineerRepo;
	
	public void saveEngineer(Engineer engineer)
	{
		engineerRepo.save(engineer);
	}
	
	public List<Engineer> getAllEngineers()
	{	
		Iterable<Engineer> iterable=engineerRepo.findAll();
		List<Engineer> engineers=new ArrayList<>();
		iterable.forEach(iter->engineers.add(iter));
		return engineers;
	}
	
	public Engineer getEngineerById(int id)
	{
		Optional<Engineer>optional=engineerRepo.findById(id);
		Engineer engineer=optional.get();
		return engineer;
	}
	
	public void updateEngineer(Engineer engineer)
	{
		engineerRepo.save(engineer);
	}
	
	public void updateEngineerPassword(String password, int id) {
		Engineer engineer=getEngineerById(id);
		engineer.setPassword(password);
		engineerRepo.save(engineer);
		
	}
	
	public void deleteEngineer(int id)
	{
		Engineer engineer=getEngineerById(id);
		engineerRepo.delete(engineer);
	}
	
	
}
