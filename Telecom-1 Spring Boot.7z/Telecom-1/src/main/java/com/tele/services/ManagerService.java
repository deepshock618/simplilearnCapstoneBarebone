package com.tele.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tele.dao.ManagerRepository;
import com.tele.entities.Manager;

@Service
public class ManagerService {

	@Autowired
	ManagerRepository managerRepo;
	
	public void saveManager(Manager manager)
	{
		managerRepo.save(manager);
	}
	
	
	public List<Manager> getAllManagers()
	{	
		Iterable<Manager> iterable=managerRepo.findAll();
		List<Manager> managers=new ArrayList<>();
		iterable.forEach(iter->managers.add(iter));
		return managers;
	}
	
	
	public Manager getManagerById(int id)
	{
		Optional<Manager>optional=managerRepo.findById(id);
		Manager manager=optional.get();
		return manager;
	}
	
	public void updateManager(Manager manager)
	{
		managerRepo.save(manager);
	}
	
	public void updateManagerPassword(String password, int id) {
		Manager manager=getManagerById(id);
		manager.setPassword(password);
		managerRepo.save(manager);
		
	}
	
	public void deleteManager(int id)
	{
		Manager manager=getManagerById(id);
		managerRepo.delete(manager);
	}
}
